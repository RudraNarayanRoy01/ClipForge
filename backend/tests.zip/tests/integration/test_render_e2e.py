import pytest
import uuid
import tempfile
import os
from unittest.mock import patch

from src.application.render_planner import RenderPlanner
from src.application.render_validator import RenderValidator
from src.application.render_composition_service import RenderCompositionService
from src.application.render_planning_pipeline import RenderPlanningPipeline
from src.application.execution_models import ValidatedRenderPlan, RenderExecutionStatus, RenderExecutionResult

# Replace RenderExecutionPipeline and RenderExecutor with the new execution service
from src.application.render_execution_service import RenderExecutionService
from src.application.execution_models import RenderExecutionRequest, RenderFailureCategory
from src.domain.ports import IRenderBackend
from src.domain.models.render_result import RenderResult, RenderStatus

class DummyRenderingBackend(IRenderBackend):
    """
    Behavioral test double for IRenderBackend capable of exercising representative orchestration scenarios.
    Ensures backend neutrality by avoiding actual FFmpeg/MoviePy dependencies.
    """
    def __init__(self, simulate_failure: bool = False):
        self.simulate_failure = simulate_failure

    async def execute(self, plan: RenderPlan, output_path: str) -> RenderResult:
        if self.simulate_failure:
            return RenderResult(
                status=RenderStatus.FAILED,
                rendered_duration=0.5,
                message="Simulated architectural backend failure.",
                rendering_metadata={"error_code": "SIM_FAIL"}
            )
        return RenderResult(
            status=RenderStatus.COMPLETED,
            rendered_duration=1.0,
            rendered_output_location=output_path
        )
from src.domain.render_plan import RenderPlan
from src.domain.models.render_profile import RenderProfile
from src.domain.entities import Resolution
from src.domain.value_objects import AspectRatio

from src.editing.domain.models.state import TimelineState, TimelineMetadata, TimelineTrack
from src.editing.domain.enums.tracks import TimelineTrackType
from src.editing.domain.models.items import Clip, Subtitle, Overlay
from src.editing.domain.enums.items import TimelineItemType, ScalingMode
from src.editing.domain.value_objects.time import Time, TimeRange
from src.editing.domain.value_objects.spatial import BoundingBox, Position, Size
from src.editing.domain.pipeline.export import FinalizedEdit
from unittest.mock import MagicMock

def test_end_to_end_render_pipeline():
    """
    Verifies that TimelineState -> RenderPlanningPipeline -> RenderPlan -> RenderExecutionService -> Backend -> RenderExecutionResult
    operates as intended, without architectural leakage.
    """
    
    # 1. Setup the dummy dependencies and data
    metadata = TimelineMetadata(fps=30.0, resolution=(1920, 1080), sample_rate=44100)
    total_duration = Time(value=10.0)
    
    # Create a dummy video clip
    clip_id = uuid.uuid4()
    asset_id = uuid.uuid4()
    time_range = TimeRange(start=Time(value=0.0), end=Time(value=10.0))
    clip = Clip(
        id=clip_id,
        item_type=TimelineItemType.CLIP,
        timeline_time_range=time_range,
        asset_id=asset_id,
    )
    
    # Create a dummy subtitle
    subtitle = Subtitle(
        id=uuid.uuid4(),
        item_type=TimelineItemType.SUBTITLE,
        timeline_time_range=TimeRange(start=Time(value=1.0), end=Time(value=5.0)),
        text="Test Subtitle",
        position=Position(x=100, y=900)
    )
    
    # Create a dummy overlay
    overlay = Overlay(
        id=uuid.uuid4(),
        item_type=TimelineItemType.OVERLAY,
        timeline_time_range=TimeRange(start=Time(value=0.0), end=Time(value=10.0)),
        asset_id=uuid.uuid4(),
        bounding_box=BoundingBox(origin=Position(x=0, y=0), size=Size(width=200, height=200))
    )
    
    video_track = TimelineTrack(
        id=uuid.uuid4(),
        track_type=TimelineTrackType.VIDEO,
        items=(clip,)
    )
    
    subtitle_track = TimelineTrack(
        id=uuid.uuid4(),
        track_type=TimelineTrackType.SUBTITLE,
        items=(subtitle,)
    )
    
    overlay_track = TimelineTrack(
        id=uuid.uuid4(),
        track_type=TimelineTrackType.OVERLAY,
        items=(overlay,)
    )
    
    timeline_state = TimelineState(
        video_tracks=(video_track,),
        audio_tracks=(),
        overlay_tracks=(overlay_track,),
        subtitle_tracks=(subtitle_track,),
        metadata=metadata,
        total_duration=total_duration
    )
    
    render_profile = RenderProfile(
        name="1080p HD",
        profile_type="youtube",
        resolution=Resolution(width=1920, height=1080),
        aspect_ratio=AspectRatio.RATIO_16_9,
        frame_rate=30.0,
        video_codec="libx264",
        audio_codec="aac",
        video_bitrate="5000k",
        audio_bitrate="192k",
        sample_rate=44100,
        output_container=".mp4"
    )
    
    # 2. Build the Pipelines
    planner = RenderPlanner()
    validator = RenderValidator()
    composer = RenderCompositionService()
    
    planning_pipeline = RenderPlanningPipeline(
        planner=planner,
        validator=validator,
        composer=composer
    )
    
    backend = DummyRenderingBackend(simulate_failure=False)
    execution_service = RenderExecutionService(backend=backend)
    
    # 3. Execute Planning Phase
    # FinalizedEdit -> RenderPlanningPipeline -> RenderPlan
    finalized_edit = FinalizedEdit(
        timeline=timeline_state,
        editing_sequence=MagicMock(),
        subtitle_track=MagicMock(),
        export_profile=MagicMock()
    )
    render_plan = planning_pipeline.execute(finalized_edit, render_profile)
    
    assert isinstance(render_plan, RenderPlan)
    assert len(render_plan.layers) == 4
    assert render_plan.metadata.duration_seconds == total_duration.value
    
    # Wrap in ValidatedRenderPlan (normally done by the pipeline/service layer before handing to execution service)
    # The RenderExecutionService requires a ValidatedRenderPlan
    import datetime
    validated_plan = ValidatedRenderPlan(plan=render_plan, validated_at=datetime.datetime.utcnow())
    
    # 4. Execute Rendering Phase (with the Dummy backend)
    temp_dir = tempfile.gettempdir()
    dummy_result_path = os.path.join(temp_dir, "test_render.mp4")
    
    import asyncio
    result = asyncio.run(execution_service.execute_plan(validated_plan, dummy_result_path))
    
    # Verify result is successfully obtained and no abstraction was bypassed
    assert isinstance(result, RenderExecutionResult)
    assert result.status == RenderExecutionStatus.COMPLETED
    assert result.output_artifact_path == dummy_result_path

def test_end_to_end_render_pipeline_failure():
    """
    Verifies that the orchestrator properly handles a backend failure, maintaining
    statelessness and abstraction boundaries without leaking backend exceptions.
    """
    metadata = TimelineMetadata(fps=30.0, resolution=(1920, 1080), sample_rate=44100)
    total_duration = Time(value=10.0)
    
    clip = Clip(
        id=uuid.uuid4(),
        item_type=TimelineItemType.CLIP,
        timeline_time_range=TimeRange(start=Time(value=0.0), end=Time(value=10.0)),
        asset_id=uuid.uuid4(),
    )
    
    video_track = TimelineTrack(
        id=uuid.uuid4(),
        track_type=TimelineTrackType.VIDEO,
        items=(clip,)
    )
    
    timeline_state = TimelineState(
        video_tracks=(video_track,),
        audio_tracks=(),
        overlay_tracks=(),
        subtitle_tracks=(),
        metadata=metadata,
        total_duration=total_duration
    )
    
    render_profile = RenderProfile(
        name="1080p HD",
        profile_type="youtube",
        resolution=Resolution(width=1920, height=1080),
        aspect_ratio=AspectRatio.RATIO_16_9,
        frame_rate=30.0,
        video_codec="libx264",
        audio_codec="aac",
        video_bitrate="5000k",
        audio_bitrate="192k",
        sample_rate=44100,
        output_container=".mp4"
    )
    
    planning_pipeline = RenderPlanningPipeline(
        planner=RenderPlanner(),
        validator=RenderValidator(),
        composer=RenderCompositionService()
    )
    
    backend = DummyRenderingBackend(simulate_failure=True)
    execution_service = RenderExecutionService(backend=backend)
    
    finalized_edit = FinalizedEdit(
        timeline=timeline_state,
        editing_sequence=MagicMock(),
        subtitle_track=MagicMock(),
        export_profile=MagicMock()
    )
    
    render_plan = planning_pipeline.execute(finalized_edit, render_profile)
    
    import datetime
    validated_plan = ValidatedRenderPlan(plan=render_plan, validated_at=datetime.datetime.utcnow())
    
    temp_dir = tempfile.gettempdir()
    dummy_result_path = os.path.join(temp_dir, "test_render_fail.mp4")
    
    import asyncio
    result = asyncio.run(execution_service.execute_plan(validated_plan, dummy_result_path))
    
    assert isinstance(result, RenderExecutionResult)
    assert result.status == RenderExecutionStatus.FAILED
    assert result.diagnostics is not None
    assert result.diagnostics.category == RenderFailureCategory.BACKEND_FAILURE
    assert result.diagnostics.details["error_code"] == "SIM_FAIL"


